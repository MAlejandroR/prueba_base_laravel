<nav class="bg-nav h-nav flex flex-row justify-start items-center space-x-2 px-3">
    <button class="btn btn-soft btn-primary">
        <a href="about">About</a>
    </button>
    <button class="btn btn-soft btn-secondary">
        Noticias
    </button>
    <button class="btn btn-soft btn-warning">
        Contactar
    </button>

</nav>
