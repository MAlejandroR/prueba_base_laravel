<x-layouts.layout>
    <h1>Estoy en la sección about</h1>

</x-layouts.layout>
